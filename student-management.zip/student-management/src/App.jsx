import { useState } from 'react';
import './App.css';

function App() {
  const [students, setStudents] = useState([
    { id: Math.floor(Math.random() * 10000), name: 'John Doe', age: 20, email: 'john@example.com', major: 'Computer Science' },
    { id: Math.floor(Math.random() * 10000), name: 'Jane Smith', age: 22, email: 'jane@example.com', major: 'Physics' },
  ]);

  const [newStudent, setNewStudent] = useState({
    name: '',
    age: '',
    email: '',
    major: 'Computer Science',
  });

  const addStudent = () => {
    if (newStudent.name && newStudent.age && newStudent.email) {
      setStudents([
        ...students,
        { 
          id: Math.floor(Math.random() * 10000), 
          name: newStudent.name, 
          age: newStudent.age, 
          email: newStudent.email, 
          major: newStudent.major 
        },
      ]);
      setNewStudent({ name: '', age: '', email: '', major: 'Computer Science' });
    }
  };

  const deleteStudent = (id) => {
    setStudents(students.filter(student => student.id !== id));
  };

  return (
    <div className="App">
      <h1>🎓 Student Management List</h1>

      <div className="student-form">
        <input
          type="text"
          placeholder="Enter Student Name"
          value={newStudent.name}
          onChange={(e) => setNewStudent({ ...newStudent, name: e.target.value })}
          className="input-field"
        />
        <input
          type="number"
          placeholder="Enter Student Age"
          value={newStudent.age}
          onChange={(e) => setNewStudent({ ...newStudent, age: e.target.value })}
          className="input-field"
        />
        <input
          type="email"
          placeholder="Enter Student Email"
          value={newStudent.email}
          onChange={(e) => setNewStudent({ ...newStudent, email: e.target.value })}
          className="input-field"
        />
        <select
          value={newStudent.major}
          onChange={(e) => setNewStudent({ ...newStudent, major: e.target.value })}
          className="input-field"
        >
          <option value="Computer Science">Computer Science</option>
          <option value="Physics">Physics</option>
          <option value="Mathematics">Mathematics</option>
          <option value="Engineering">Engineering</option>
          <option value="Biology">Biology</option>
        </select>
        <button className="btn-add" onClick={addStudent}>
          Add Student
        </button>
      </div>

      <ul className="student-list">
        {students.map((student) => (
          <li key={student.id} className="student-item">
            <span><strong>ID:</strong> {student.id}</span>
            <span><strong>Name:</strong> {student.name}</span>
            <span><strong>Age:</strong> {student.age}</span>
            <span><strong>Email:</strong> {student.email}</span>
            <span><strong>Major:</strong> {student.major}</span>
            <button className="btn-delete" onClick={() => deleteStudent(student.id)}>
              Remove
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;






